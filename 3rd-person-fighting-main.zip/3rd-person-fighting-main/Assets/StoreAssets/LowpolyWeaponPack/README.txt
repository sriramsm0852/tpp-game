Free 3d model let you easily add this items to your game and scenes. It will be really efficient for your mobile games. 
This pack contains the following(verts/faces/tris): 
- sword 65/58/126 
- shield 99/86/170 
- staff 184/184/352 
- bow 540/226/460 
- arrow 51/40/94 
- quiver 72/65/134 
- weapon stand 203/185/315 

Additional: 
- one example scene 
- 3 variants of the texture (red, green, blue) in 256*256 resolution. You can switch them using one of three materials in Materials folder. 


Support Mail 
arhitector13@yandex.ru