using System;
using System.Collections.Generic;
using UnityEngine;

public class StatsData
{
    public int health;

    public StatsData()
    {
        health = 100;
    }
}
